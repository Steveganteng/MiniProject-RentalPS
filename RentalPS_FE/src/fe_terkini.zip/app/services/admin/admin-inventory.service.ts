import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface ConsoleTypeItem {
  id: number;
  name: string;
  hourlyRate: number;
  isActive: boolean;
}

export interface ConsoleUnitItem {
  id: number;
  consoleTypeId: number;
  consoleTypeName: string;
  roomId: number | null;
  roomNumber: string | null;
  unitCode: string;
  statusConsole: string;
}

export interface RoomTypeItem {
  id: number;
  name: string;
  additionalHourlyRate: number;
  description: string;
  isActive: boolean;
}

export interface RoomItem {
  id: number;
  roomTypeId: number;
  roomNumber: string;
  description: string;
  statusRoom: string;
}

export interface StickTypeItem {
  id: number;
  consoleTypeId: number;
  name: string;
  additionalHourlyRate: number;
  isActive: boolean;
}

export interface StickItem {
  id: number;
  stickTypeId: number;
  stickCode: string;
  statusStick: string;
}

@Injectable({ providedIn: 'root' })
export class AdminInventoryService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiUrl;

  getConsoleTypes(): Observable<ConsoleTypeItem[]> {
    return this.http.get<ConsoleTypeItem[]>(`${this.baseUrl}/console-types`);
  }

  createConsoleType(payload: Omit<ConsoleTypeItem, 'id'>): Observable<ConsoleTypeItem> {
    return this.http.post<ConsoleTypeItem>(`${this.baseUrl}/console-types`, payload);
  }

  updateConsoleType(id: number, payload: Omit<ConsoleTypeItem, 'id'>): Observable<ConsoleTypeItem> {
    return this.http.put<ConsoleTypeItem>(`${this.baseUrl}/console-types/${id}`, payload);
  }

  deactivateConsoleType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/console-types/${id}`);
  }

  getConsoleUnits(): Observable<ConsoleUnitItem[]> {
    return this.http.get<ConsoleUnitItem[]>(`${this.baseUrl}/console-unit`);
  }

  createConsoleUnit(payload: Omit<ConsoleUnitItem, 'id' | 'consoleTypeName' | 'roomNumber'>): Observable<ConsoleUnitItem> {
    return this.http.post<ConsoleUnitItem>(`${this.baseUrl}/console-unit`, payload);
  }

  updateConsoleUnit(id: number, payload: Omit<ConsoleUnitItem, 'id' | 'consoleTypeName' | 'roomNumber'>): Observable<ConsoleUnitItem> {
    return this.http.put<ConsoleUnitItem>(`${this.baseUrl}/console-unit/${id}`, payload);
  }

  deactivateConsoleUnit(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/console-unit/${id}`);
  }

  getRoomTypes(): Observable<RoomTypeItem[]> {
    return this.http.get<RoomTypeItem[]>(`${this.baseUrl}/room-types`);
  }

  createRoomType(payload: Omit<RoomTypeItem, 'id'>): Observable<RoomTypeItem> {
    return this.http.post<RoomTypeItem>(`${this.baseUrl}/room-types`, payload);
  }

  updateRoomType(id: number, payload: Omit<RoomTypeItem, 'id'>): Observable<RoomTypeItem> {
    return this.http.put<RoomTypeItem>(`${this.baseUrl}/room-types/${id}`, payload);
  }

  deactivateRoomType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/room-types/${id}`);
  }

  getRooms(): Observable<RoomItem[]> {
    return this.http.get<RoomItem[]>(`${this.baseUrl}/rooms`);
  }

  createRoom(payload: Omit<RoomItem, 'id'>): Observable<RoomItem> {
    return this.http.post<RoomItem>(`${this.baseUrl}/rooms`, payload);
  }

  updateRoom(id: number, payload: Omit<RoomItem, 'id'>): Observable<RoomItem> {
    return this.http.put<RoomItem>(`${this.baseUrl}/rooms/${id}`, payload);
  }

  deactivateRoom(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/rooms/${id}`);
  }

  getStickTypes(): Observable<StickTypeItem[]> {
    return this.http.get<StickTypeItem[]>(`${this.baseUrl}/stick-types`);
  }

  createStickType(payload: Omit<StickTypeItem, 'id'>): Observable<StickTypeItem> {
    return this.http.post<StickTypeItem>(`${this.baseUrl}/stick-types`, payload);
  }

  updateStickType(id: number, payload: Omit<StickTypeItem, 'id'>): Observable<StickTypeItem> {
    return this.http.put<StickTypeItem>(`${this.baseUrl}/stick-types/${id}`, payload);
  }

  deactivateStickType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/stick-types/${id}`);
  }

  getSticks(): Observable<StickItem[]> {
    return this.http.get<StickItem[]>(`${this.baseUrl}/sticks`);
  }

  createStick(payload: Omit<StickItem, 'id'>): Observable<StickItem> {
    return this.http.post<StickItem>(`${this.baseUrl}/sticks`, payload);
  }

  updateStick(id: number, payload: Omit<StickItem, 'id'>): Observable<StickItem> {
    return this.http.put<StickItem>(`${this.baseUrl}/sticks/${id}`, payload);
  }

  deactivateStick(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/sticks/${id}`);
  }
}
